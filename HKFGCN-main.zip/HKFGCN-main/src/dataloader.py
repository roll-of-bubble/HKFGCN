import logging
import os
import torch
import pandas as pd
import numpy as np
import scipy.io as scio
from sklearn.model_selection import KFold
from torch.utils.data import DataLoader
from torch.utils.data.sampler import BatchSampler, RandomSampler, SequentialSampler
import pytorch_lightning as pl
import scipy.sparse as sp
from . import DATA_TYPE_REGISTRY

class DRDataset():
    def __init__(self, dataset_name="MDAD", drug_neighbor_num=15, microbe_neighbor_num=15):
        assert dataset_name in ["aBiofilm","MDAD","DrugVirus","egatmda_dataset"]
        self.dataset_name = dataset_name

        if dataset_name=="egatmda_dataset":
            old_data=load_EGATMDA_DATASET_MDAD()
        elif dataset_name=="aBiofilm":
            old_data=load_aBiofilm()
        elif dataset_name == "MDAD":
            old_data = load_MDAD()
        elif dataset_name == "DrugVirus":
            old_data = load_DrugVirus()

        else:
            old_data = scio.loadmat(f"dataset/{dataset_name}.mat")

        self.drug_sim = old_data["drug"].astype(np.float)   #药物相似
        self.microbe_sim = old_data["microbe"].astype(np.float) #微生物相似
        self.drug_name = old_data["Wrname"].reshape(-1)
        #self.drug_name_new = old_data["Wrname"].reshape(-1) #新加
        self.drug_num = len(self.drug_name)
        self.microbe_name = old_data["Wdname"].reshape(-1)
        self.microbe_num = len(self.microbe_name)
        self.interactions = old_data["didr"].T #转置

        self.drug_edge = self.build_graph(self.drug_sim, drug_neighbor_num)
        self.microbe_edge = self.build_graph(self.microbe_sim, microbe_neighbor_num)
        pos_num = self.interactions.sum()  #阳性样本个数
        neg_num = np.prod(self.interactions.shape) - pos_num  #阴性样本个数：np.prod所有维度的乘积-阳性样本的个数
        self.pos_weight = neg_num / pos_num
        print(f"dataset:{dataset_name}, drug:{self.drug_num}, microbe:{self.microbe_num}, pos weight:{self.pos_weight}")

    def build_graph(self, sim, num_neighbor):  #构建图
        if num_neighbor>sim.shape[0] or num_neighbor<0:#sim.shape[0]是相似性矩阵
            num_neighbor = sim.shape[0]   #本来取15个，但是如果和其相似的没有15个，那么有几个取几个
        neighbor = np.argpartition(-sim, kth=num_neighbor, axis=1)[:, :num_neighbor]     #这里-sim是数组，首先我们要明白的是argpartition函数输出的是一个索引数组
        row_index = np.arange(neighbor.shape[0]).repeat(neighbor.shape[1])  #.repeat重复数组中的元素  row行
        col_index = neighbor.reshape(-1)   #变成一维的了
        edge_index = torch.from_numpy(np.array([row_index, col_index]).astype(int))
        values = torch.ones(edge_index.shape[1])
        values = torch.from_numpy(sim[row_index, col_index]).float()*values
        return (edge_index, values, sim.shape)

    @staticmethod
    def add_argparse_args(parent_parser):
        parser = parent_parser.add_argument_group("dataset config")
        parser.add_argument("--dataset_name", default="MDAD",
                                   choices=["aBiofilm","MDAD","DrugVirus","egatmda_dataset"])
        parser.add_argument("--drug_neighbor_num", default=15, type=int)
        parser.add_argument("--microbe_neighbor_num", default=15, type=int)
        return parent_parser



class Dataset():
    def __init__(self, dataset, mask, fill_unkown=True, stage="train", **kwargs):
        mask = mask.astype(bool)
        self.stage = stage
        self.one_mask = torch.from_numpy(dataset.interactions>0)
        row, col = np.nonzero(mask&dataset.interactions.astype(bool))
        self.valid_row = torch.tensor(np.unique(row))  #该函数是去除数组中的重复数字，并进行排序之后输出。
        self.valid_col = torch.tensor(np.unique(col))
        if not fill_unkown:
            row_idx, col_idx = np.nonzero(mask)
            self.interaction_edge = torch.LongTensor([row_idx, col_idx]).contiguous()
            self.label = torch.from_numpy(dataset.interactions[mask]).float().contiguous()
            self.valid_mask = torch.ones_like(self.label, dtype=torch.bool)
            self.matrix_mask = torch.from_numpy(mask)
        else:
            row_idx, col_idx = torch.meshgrid(torch.arange(mask.shape[0]), torch.arange(mask.shape[1])) #torch.meshgrid（）的功能是生成网格，可以用于生成坐标。函数输入两个数据类型相同的一维张量，两个输出张量的行数为第一个输入张量的元素个数，列数为第二个输入张量的元素个数，当两个输入张量数据类型不同或维度不是一维时会报错。
            self.interaction_edge = torch.stack([row_idx.reshape(-1), col_idx.reshape(-1)])  # torch.stack（）官方解释：沿着一个新维度对输入张量序列进行连接。 序列中所有的张量都应该为相同形状。
            self.label = torch.clone(torch.from_numpy(dataset.interactions)).float()  #torch.clone返回一个和源张量同shape、dtype和device的张量，与源张量不共享数据内存，但提供梯度的回溯
            self.label[~mask] = 0
            self.valid_mask = torch.from_numpy(mask)
            self.matrix_mask = torch.from_numpy(mask)

        self.drug_edge = dataset.drug_edge
        self.microbe_edge = dataset.microbe_edge

        self.u_embedding = torch.from_numpy(dataset.drug_sim).float() #torch.from_numpy(ndarray) → Tensor，即 从numpy.ndarray创建一个张量。
        self.v_embedding = torch.from_numpy(dataset.microbe_sim).float()

        self.mask = torch.from_numpy(mask)
        pos_num = self.label.sum().item()
        neg_num = np.prod(self.mask.shape) - pos_num
        self.pos_weight = neg_num / pos_num

    def __str__(self):
        return f"{self.__class__.__name__}(shape={self.mask.shape}, interaction_num={len(self.interaction_edge)}, pos_weight={self.pos_weight})"

    @property
    def size_u(self):
        return self.mask.shape[0]

    @property
    def size_v(self):
        return self.mask.shape[1]

    def get_u_edge(self, union_graph=False):
        edge_index, value, size = self.drug_edge
        if union_graph:
            size = (self.size_u+self.size_v, )*2   #（1546，1546）
        return edge_index, value, size

    def get_v_edge(self, union_graph=False):
        edge_index, value, size = self.microbe_edge
        if union_graph:
            edge_index = edge_index + torch.tensor(np.array([[self.size_u], [self.size_u]]))
            size = (self.size_u + self.size_v,) * 2
        return edge_index, value, size

    def get_uv_edge(self, union_graph=False):
        train_mask = self.mask if self.stage=="train" else ~self.mask
        train_one_mask = train_mask & self.one_mask
        edge_index = torch.nonzero(train_one_mask).T
        value = torch.ones(edge_index.shape[1])
        size =  (self.size_u, self.size_v)
        if union_graph:
            edge_index = edge_index + torch.tensor([[0], [self.size_u]])
            size = (self.size_u + self.size_v,) * 2
        return edge_index, value, size

    def get_vu_edge(self, union_graph=False):
        edge_index, value, size = self.get_uv_edge(union_graph=union_graph)
        edge_index = reversed(edge_index)
        return edge_index, value, size

    def get_union_edge(self, union_type="u-uv-vu-v"):
        types = union_type.split("-")
        edges = []
        size = (self.size_u+self.size_v, )*2
        for type in types:
            assert type in ["u","v","uv","vu"]
            edge = self.__getattribute__(f"get_{type}_edge")(union_graph=True)
            edges.append(edge)
        edge_index = torch.cat([edge[0].int() for edge in edges], dim=1)
        value = torch.cat([edge[1] for edge in edges], dim=0) #torch.cat（）在给定维度上对输入的张量序列seq 进行连接操作。
        return edge_index, value, size

    @staticmethod
    def collate_fn(batch):
        return batch

# batch_size=1024*5 epochs 64 auroc:0.9357351384806536-aupr:0.553179962144391 Cdataset
# batch_size=1024*5 epochs 32 auroc:0.9353403407919936-aupr:0.5319780678531647 Cdataset
# batch_size=1024*10 epochs 128 auroc:0.9205757164088856-aupr:0.5228925211295569
# batch_size=1024*10 epochs 64 auroc:0.9161912302288697-aupr:0.4971947471119751
# batch_size=1024*10 epochs 32 auroc:0.8978203124764995-aupr:0.3906882262477967
# batch_size=1024*5 epochs 64 auroc:0.9214539160124139-aupr:0.5080356373187406
# batch_size=1024*5 epochs 32 auroc:0.9233284816950948-aupr:0.4833606718343333
# batch_size=1024*1 epochs 32 auroc:0.9190991473694987-aupr:0.44253258179201654
class GraphDataIterator(DataLoader): #图数据迭代器
    def __init__(self, dataset, mask, fill_unkown=True, stage="train", batch_size=1024*5, shuffle=False,
                 dataset_type="FullGraphDataset", **kwargs):
        # assert dataset_type in ["FullGraphDataset", "PairGraphDataset"]
        dataset_cls = DATA_TYPE_REGISTRY.get(dataset_type)
        dataset = dataset_cls(dataset, mask, fill_unkown, stage=stage, **kwargs)
        if len(dataset)<batch_size:
            logging.info(f"dataset size:{len(dataset)}, batch_size:{batch_size} is invalid!")
            batch_size = min(len(dataset), batch_size)
        if shuffle and stage=="train":
            sampler = RandomSampler(dataset) #RandomSampler随机样本的元素。如果没有替换，则从打乱的数据集取样。如果需要替换，则用户可以指定要绘制的num_samples。
        else:
            sampler = SequentialSampler(dataset)#SequentialSampler按顺序采样元素，总是按照相同的顺序 按顺序对数据集采样
        batch_sampler = BatchSampler(sampler, batch_size=batch_size, drop_last=False)  #也就是说BatchSampler的作用就是将前面的Sampler采样得到的索引值进行合并，当数量等于一个batch大小后就将这一批的索引值返回。
        super(GraphDataIterator, self).__init__(dataset=dataset, batch_size=None, sampler=batch_sampler,
                                            collate_fn=Dataset.collate_fn, **kwargs)


class CVDataset(pl.LightningDataModule):  #用來交叉驗證
    """use for cross validation
       split_mode | n_splits |  drug_id   |   microbe_id | description
       global     |   1      |   *        |     *        | case study
       global     |  10      |   *        |     *        | 10 fold
       local      |  -1      |   not None |     *        | local leave one for remove drug
       local      |  -1      |   None     |     not None | local leave one for remove microbe
       local      |   1      |   int      |     *        | local leave one for remove specific drug
       local      |   1      |   None     |     int      | local leave one for remove specific drug
    """
    def __init__(self, dataset, split_mode="global", n_splits=5,
                 drug_idx=None, microbe_idx=None, global_test_all_zero=False,
                 train_fill_unknown=True, seed=666, cached_dir="cached",
                 dataset_type="FullGraphDataset",
                 **kwargs):
        super(CVDataset, self).__init__()
        self.dataset = dataset
        self.split_mode = split_mode
        self.n_splits = n_splits
        self.global_test_all_zero = global_test_all_zero
        self.train_fill_unknown = train_fill_unknown
        self.seed = seed
        self.row_idx = drug_idx  #行
        self.col_idx = microbe_idx  #列
        self.dataset_type = dataset_type
        self.save_dir = os.path.join(cached_dir, dataset.dataset_name,#路径拼接Path20 = os.path.join(Path1,Path2,Path3)   Path20 = home\develop\code
                                     f"{self.split_mode}_{len(self)}_split_{self.row_idx}_{self.col_idx}")
        assert isinstance(n_splits, int) and n_splits>=-1

    @staticmethod
    def add_argparse_args(parent_parser):
        parser = parent_parser.add_argument_group("cross validation config")
        parser.add_argument("--split_mode", default="global", choices=["global", "local"])
        parser.add_argument("--n_splits", default=5, type=int)
        parser.add_argument("--drug_idx", default=None, type=int)
        parser.add_argument("--microbe_idx", default=None, type=int)
        parser.add_argument("--global_test_all_zero", default=False, action="store_true", help="全局模式每折测试集是否测试所有未验证关联，默认：不测试")
        parser.add_argument("--train_fill_unknown", default=True, action="store_true", help="训练集中是否将测试集关联填0还是丢弃，默认：丢弃")
        parser.add_argument("--dataset_type", default=None, choices=["FullGraphDataset", "PairGraphDataset"])
        parser.add_argument("--seed", default=666, type=int)
        return parent_parser

    def fold_mask_iterator(self, interactions, mode="global", n_splits=5, row_idx=None, col_idx=None, global_test_all_zero=False, seed=666):
        assert mode in ["global", "local"]
        assert n_splits>=-1 and isinstance(n_splits, int)
        if mode=="global":
            if n_splits==1:
                mask = np.ones_like(interactions, dtype="bool")
                yield mask, mask
            else:
                kfold = KFold(n_splits=n_splits, shuffle=True, random_state=seed)
                pos_row, pos_col = np.nonzero(interactions)
                neg_row, neg_col = np.nonzero(1 - interactions)
                assert len(pos_row) + len(neg_row) == np.prod(interactions.shape)
                for (train_pos_idx, test_pos_idx), (train_neg_idx, test_neg_idx) in zip(kfold.split(pos_row),
                                                                                        kfold.split(neg_row)):
                    train_mask = np.zeros_like(interactions, dtype="bool")
                    test_mask = np.zeros_like(interactions, dtype="bool")
                    if global_test_all_zero:
                        test_neg_idx = np.arange(len(neg_row))
                    train_pos_edge = np.stack([pos_row[train_pos_idx], pos_col[train_pos_idx]])
                    train_neg_edge = np.stack([neg_row[train_neg_idx], neg_col[train_neg_idx]])
                    test_pos_edge = np.stack([pos_row[test_pos_idx], pos_col[test_pos_idx]])
                    test_neg_edge = np.stack([neg_row[test_neg_idx], neg_col[test_neg_idx]])
                    train_edge = np.concatenate([train_pos_edge, train_neg_edge], axis=1)
                    test_edge = np.concatenate([test_pos_edge, test_neg_edge], axis=1)
                    train_mask[train_edge[0], train_edge[1]] = True
                    test_mask[test_edge[0], test_edge[1]] = True
                    yield train_mask, test_mask
        elif mode=="local":
            if row_idx is not None:
                row_idxs = list(range(interactions.shape[0])) if n_splits==-1 else [row_idx]
                for idx in row_idxs:
                    yield self.get_fold_local_mask(interactions, row_idx=idx)
            elif col_idx is not None:
                col_idxs = list(range(interactions.shape[1])) if n_splits==-1 else [col_idx]
                for idx in col_idxs:
                    yield self.get_fold_local_mask(interactions, col_idx=idx)
        else:
            raise NotImplemented

    def get_fold_local_mask(self, interactions, row_idx=None, col_idx=None):
        train_mask = np.ones_like(interactions, dtype="bool")
        test_mask = np.zeros_like(interactions, dtype="bool")
        if row_idx is not None:
            train_mask[row_idx, :] = False
            test_mask[np.ones(interactions.shape[1], dtype="int")*row_idx,
                      np.arange(interactions.shape[1])] = True
        elif col_idx is not None:
            train_mask[:,col_idx] = False
            test_mask[np.arange(interactions.shape[0]),
                      np.ones(interactions.shape[0], dtype="int") * col_idx] = True
        return train_mask, test_mask

    def prepare_data(self):
        save_dir = self.save_dir
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        import glob
        if len(glob.glob(os.path.join(save_dir, "split_*.mat")))!=len(self):
            for i, (train_mask, test_mask) in enumerate(self.fold_mask_iterator(interactions=self.dataset.interactions,
                                                                 mode=self.split_mode,
                                                                 n_splits=self.n_splits,
                                                                 global_test_all_zero=self.global_test_all_zero,
                                                                 row_idx=self.row_idx,
                                                                 col_idx=self.col_idx)):
                scio.savemat(os.path.join(save_dir, f"split_{i}.mat"),
                             {"train_mask":train_mask,
                              "test_mask":test_mask},
                             )

        data = scio.loadmat(os.path.join(self.save_dir, f"split_{self.fold_id}.mat"))
        self.train_mask = data["train_mask"]
        self.test_mask = data["test_mask"]

    def train_dataloader(self):
        return GraphDataIterator(self.dataset, self.train_mask, fill_unkown=self.train_fill_unknown,
                                 stage="train", dataset_type=self.dataset_type)

    def val_dataloader(self):
        return GraphDataIterator(self.dataset, self.test_mask, fill_unkown=True,
                                 stage="val", dataset_type=self.dataset_type)

    def __iter__(self):
        for fold_id in range(len(self)):
            self.fold_id = fold_id
            yield self

    def __len__(self):
        if self.split_mode=="global":
            return self.n_splits
        elif self.split_mode=="local":
            if self.n_splits==-1:
                if self.row_idx is not None:
                    return self.dataset.interactions.shape[0]
                elif self.col_idx is not None:
                    return self.dataset.interactions.shape[1]
            else:
                return 1

def load_DRIMC(root_dir="dataset/drimc", name="c", reduce=True):
    """ C drug:658, microbe:409 association:2520 (False 2353)
        PREDICT drug:593, microbe:313 association:1933 (Fdataset)
        LRSSL drug: 763, microbe:681, association:3051
    """
    drug_chemical = pd.read_csv(os.path.join(root_dir, f"{name}_simmat_dc_chemical.txt"), sep="\t", index_col=0)
    drug_domain = pd.read_csv(os.path.join(root_dir, f"{name}_simmat_dc_domain.txt"), sep="\t", index_col=0)
    drug_go = pd.read_csv(os.path.join(root_dir, f"{name}_simmat_dc_go.txt"), sep="\t", index_col=0)
    microbe_sim = pd.read_csv(os.path.join(root_dir, f"{name}_simmat_dg.txt"), sep="\t", index_col=0)
    if reduce:
        drug_sim =  (drug_chemical+drug_domain+drug_go)/3
    else:
        drug_sim = drug_chemical
    drug_microbe = pd.read_csv(os.path.join(root_dir, f"{name}_admat_dgc.txt"), sep="\t", index_col=0).T
    if name=="lrssl":
        drug_microbe = drug_microbe.T
    rr = drug_sim.to_numpy(dtype=np.float32)  #药物药物相似性
    rd = drug_microbe.to_numpy(dtype=np.float32)  #药物微生物
    dd = microbe_sim.to_numpy(dtype=np.float32)#微生物微生物相似性
    rname = drug_sim.columns.to_numpy()
    dname = microbe_sim.columns.to_numpy()
    return {"drug":rr,
            "microbe":dd,
            "Wrname":rname,
            "Wdname":dname,
            "didr":rd.T}


def load_HDVD(root_dir="dataset/hdvd"):
    """drug:219, virus:34, association: 455"""

    dd = pd.read_csv(os.path.join(root_dir, "virussim.csv"), index_col=0).to_numpy(np.float32)
    rd = pd.read_csv(os.path.join(root_dir, "virusdrug.csv"), index_col=0)
    rr = pd.read_csv(os.path.join(root_dir, "drugsim.csv"), index_col=0).to_numpy(np.float32)
    rname = rd.index.to_numpy()
    dname = rd.columns.to_numpy()
    rd = rd .to_numpy(np.float32)
    return {"drug":rr,
            "microbe":dd,
            "Wrname":rname,
            "Wdname":dname,
            "didr":rd.T}


def read_data(file):
    return pd.read_csv(file, header=None).to_numpy(dtype=np.float32)

def read_data_txt(file):
    return open(file,"r")

# def read_data_new(file):
#     return pd.read_csv(file).to_numpy(dtype=np.float32)
#
#
# def read_data_xlsx(file):
#     return pd.read_excel(file).to_numpy(dtype=np.float32)

def load_LAGCN(root_dir="dataset/lagcn"):
    """drug:598, microbe:269 association:18416
    """
    dd = read_data(os.path.join(root_dir, "dis_sim.csv"))
    rd = read_data(os.path.join(root_dir, "drug_dis.csv"))
    rr = read_data(os.path.join(root_dir, "drug_sim.csv"))
    dname = np.arange(dd.shape[0])
    rname = np.arange(rr.shape[0])
    return {"drug":rr,
            "microbe":dd,
            "Wrname":rname,
            "Wdname":dname,
            "didr":rd.T}

#11111111111111111111111111111111111111111111111111111111111111111分界线1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111

def load_MDAD(root_dir="dataset/MKGCN_MicrobeDrugA/MDAD"):

    rr = np.loadtxt( 'dataset/MKGCN_MicrobeDrugA/MDAD/drugsimilarity.txt', dtype=np.float32,delimiter='\t')  # 数组(1373，1373）-1885129
    dd = np.loadtxt( 'dataset/MKGCN_MicrobeDrugA/MDAD/microbesimilarity.txt',dtype=np.float32, delimiter='\t')  # 数组（173,173）-29929
    adj_triple = np.loadtxt( 'dataset/MKGCN_MicrobeDrugA/MDAD/adj.txt',dtype=np.float32)  # 元组(2470,3)
    rd = sp.csc_matrix((adj_triple[:, 2], (adj_triple[:, 0] - 1, adj_triple[:, 1] - 1)),  # 1373,173
                                    shape=(len(rr), len(dd))).toarray()
    dname = np.arange(173)
    rname = np.arange(1373)
    return {"drug": rr,
            "microbe": dd,  # 微生物
            "Wrname": rname,
            "Wdname": dname,
            "didr": rd.T}

def load_aBiofilm(root_dir="dataset/MKGCN_MicrobeDrugA/aBiofilm"):
    """drug:1720, MICROBES:140 association:2884
    """
    rr = np.loadtxt('dataset/MKGCN_MicrobeDrugA/aBiofilm/drugsimilarity.txt', dtype=np.float32,
                    delimiter='\t')  # 数组(1373，1373）-1885129
    dd = np.loadtxt('dataset/MKGCN_MicrobeDrugA/aBiofilm/microbesimilarity.txt', dtype=np.float32,
                    delimiter='\t')  # 数组（173,173）-29929
    adj_triple = np.loadtxt('dataset/MKGCN_MicrobeDrugA/aBiofilm/adj.txt', dtype=np.float32)  # 元组(2470,3)
    rd = sp.csc_matrix((adj_triple[:, 2], (adj_triple[:, 0] - 1, adj_triple[:, 1] - 1)),  # 1373,173
                       shape=(len(rr), len(dd))).toarray()        # rr = read_data_txt(os.path.join(root_dir, "drug_features.txt"))

    dname = np.arange(140)
    rname = np.arange(1720)
    return {"drug":rr,
            "microbe":dd, #微生物
            "Wrname":rname,
            "Wdname":dname,
            "didr":rd.T}

def load_DrugVirus(root_dir="dataset/MKGCN_MicrobeDrugA/DrugVirus"):
    """drug:175, MICROBES:95 association:933
      """
    rr = np.loadtxt('dataset/MKGCN_MicrobeDrugA/DrugVirus/drugsimilarity.txt', dtype=np.float32,
                    delimiter='\t')
    dd = np.loadtxt('dataset/MKGCN_MicrobeDrugA/DrugVirus/microbesimilarity.txt', dtype=np.float32,
                    delimiter='\t')
    adj_triple = np.loadtxt('dataset/MKGCN_MicrobeDrugA/DrugVirus/adj.txt', dtype=np.float32)  # 元组(2470,3)
    rd = sp.csc_matrix((adj_triple[:, 2], (adj_triple[:, 0] - 1, adj_triple[:, 1] - 1)),
                       shape=(len(rr), len(dd))).toarray()

    dname = np.arange(95)
    rname = np.arange(175)
    return {"drug": rr,
            "microbe": dd,  # 微生物
            "Wrname": rname,
            "Wdname": dname,
            "didr": rd.T}

def load_EGATMDA_DATASET_MDAD(root_dir="dataset/egatmda_dataset"):
    """drug:1373, MICROBES:173 association:2470
    """
    dd=np.loadtxt('dataset/egatmda_dataset/microbe_features.txt', dtype=np.float32)       # dd = read_data_txt(os.path.join(root_dir, "microbe_features.txt"))
    # rd = scio.loadmat(f"dataset/net1.mat")["interaction"]   #net1                      #(os.path.join(root_dir, "drug_microbe_interactions.csv"))
    rd = scio.loadmat(f"dataset/net2.mat")["net2"]   #net2
    # rd = scio.loadmat(f"dataset/net3.mat")["net3_sub"]   #net3
    #rd = scio.loadmat(f"dataset/net123.mat")["net123"]   #net123
    rr=np.loadtxt('dataset/egatmda_dataset/drug_features.txt', dtype=np.float32, delimiter=' ')           # rr = read_data_txt(os.path.join(root_dir, "drug_features.txt"))

    dname = np.arange(173)
    rname = np.arange(1373)
    return {"drug":rr,
            "microbe":dd, #微生物
            "Wrname":rname,
            "Wdname":dname,
            "didr":rd.T}









def load_MKGCN_DATASET_MDAD(root_dir="dataset/MKGCN_MicrobeDrugA/MDAD"):
    """drug:1373, MICROBES:173 association:2470
    """
    dd=np.loadtxt('dataset/MKGCN_MicrobeDrugA/MDAD/microbefeatures.txt', dtype=np.float32)       # dd = read_data_txt(os.path.join(root_dir, "microbe_features.txt"))

    rr=np.loadtxt('dataset/MKGCN_MicrobeDrugA/MDAD/drugfeatures.txt', dtype=np.float32, delimiter=' ')           # rr = read_data_txt(os.path.join(root_dir, "drug_features.txt"))
    adj_triple = np.loadtxt('dataset/MKGCN_MicrobeDrugA/MDAD/adj.txt')  # 元组(2470,3)
    rd = sp.csc_matrix((adj_triple[:, 2], (adj_triple[:, 0] - 1, adj_triple[:, 1] - 1)),  # 1373,173
                       shape=(len(rr), len(dd))).toarray()
    dname = np.arange(173)
    rname = np.arange(1373)
    return {"drug":rr,
            "microbe":dd, #微生物
            "Wrname":rname,
            "Wdname":dname,
            "didr":rd.T}

