# from envs.pytorch_gpu.Lib import os
from sklearn.metrics import roc_curve

from main import parse, train, report
from src.DRHGCN.model import DRHGCN
import logging
import os
import torch
import pandas as pd
import numpy as np
import numpy as np
from sklearn.metrics import roc_curve, auc
import scipy.io as scio
from sklearn.model_selection import KFold
from torch.utils.data import DataLoader
from torch.utils.data.sampler import BatchSampler, RandomSampler, SequentialSampler
import pytorch_lightning as pl
import matplotlib.pyplot as plt
if __name__=="__main__":
    # rd = scio.loadmat(f"dataset/net1.mat")
    # print (rd)
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    y_label = np.load("E:\PLOT_ROC_AUPR\label.npz.npy", allow_pickle=True)
    print(y_label.shape)
    y_pred_HKFGCN=np.load("E:\PLOT_ROC_AUPR\predict_HKFGCN.npz.npy", allow_pickle=True)
    print(y_pred_HKFGCN.shape)
    y_pred_MKHGCN = np.load("E:\PLOT_ROC_AUPR\predict_MKHGCN.npz.npy", allow_pickle=True)
    print(y_pred_MKHGCN.shape)
    y_pred_LAGCN = np.load("E:\PLOT_ROC_AUPR\predict_LAGCN.npz.npy", allow_pickle=True)
    print(y_pred_LAGCN.shape)
############################################################################################################
    y_label = np.array(y_label)
    y_pred_HKFGCN = np.array(y_pred_HKFGCN)
    fpr[0], tpr[0], _ = roc_curve(y_label, y_pred_HKFGCN)
    roc_auc[0] = auc(fpr[0], tpr[0])

    # 第二个模型预测值（因为真实值都一样，不用再加载一次）,有几个模型就照这样加几个
    y_pred_MKHGCN = np.array(y_pred_MKHGCN)
    fpr[1], tpr[1], _ = roc_curve(y_label, y_pred_MKHGCN)
    roc_auc[1] = auc(fpr[1], tpr[1])


#########################三##################################################################################
    y_pred_LAGCN = np.array(y_pred_LAGCN)
    fpr[2], tpr[2], _ = roc_curve(y_label, y_pred_LAGCN)
    roc_auc[2] = auc(fpr[2], tpr[2])





    lw = 1
    # 改图大小
    plt.figure(figsize=(5, 5))

    # 画图，上面存了几个就画几个线,记得要改fpr[]里面的数，对应上面的
    plt.plot(fpr[0], tpr[0],
             lw=lw, label="HKFGCN" + ' (AUC=%0.3f)' % roc_auc[0], color='red')
    plt.plot(fpr[1], tpr[1],
             lw=lw, label="MKHGCN" + ' (AUC=%0.3f)' % roc_auc[1], color='blue')
    plt.plot(fpr[2], tpr[2],
             lw=lw, label="LAGCN" + ' (AUC=%0.3f)' % roc_auc[1], color='green')

    plt.plot([0, 1], [0, 1], color='black', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.0])
    # plt.xticks(font="Times New Roman",size=18,weight="bold")
    # plt.yticks(font="Times New Roman",size=18,weight="bold")
    fontsize = 12

    plt.title("Receiver Operating Characteristic curve")
    plt.xlabel('False Positive Rate', fontsize=fontsize)
    plt.ylabel('True Positive Rate', fontsize=fontsize)
    plt.legend(loc="lower right", fontsize=9)

    # 图片保存的地方
    plt.savefig("E:\PLOT_ROC_AUPR")
    plt.show()