from .register import Registry

MODEL_REGISTRY = Registry("Model")
DATA_TYPE_REGISTRY = Registry("DataType")
